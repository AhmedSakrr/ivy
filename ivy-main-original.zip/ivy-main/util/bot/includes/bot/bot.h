#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#pragma once


/*
    *    util/bot/includes/bot/bot.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/