#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma once


/*
    *    util/loader/includes/parser/parse.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void parse(char *buffer, char *remove);
void string_handler(char *username, char *data);