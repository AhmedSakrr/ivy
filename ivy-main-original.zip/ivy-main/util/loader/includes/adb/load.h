#include <stdio.h>
#include <stdlib.h>
#pragma once


/*
    *    util/loader/includes/adb/load.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void adb_load(char *filename, char *payload);