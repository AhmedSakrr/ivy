#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#pragma once


/*
    *    util/loader/includes/loader/loader.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/