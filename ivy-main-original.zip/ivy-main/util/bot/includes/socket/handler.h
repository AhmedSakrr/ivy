#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma once


/*
    *    util/bot/includes/socket/handler.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void command_handler(char *buffer);