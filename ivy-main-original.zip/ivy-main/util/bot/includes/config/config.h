#pragma once


/*
    *    util/bot/includes/config/config.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


#define C2_IP "127.0.0.1"
#define C2_PORT 1337