#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#pragma once


/*
    *    util/bot/includes/socket/socket.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


bool connect_server(void);