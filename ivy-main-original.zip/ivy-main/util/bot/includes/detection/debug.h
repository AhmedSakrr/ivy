#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/ptrace.h>
#include <sys/syscall.h>
#pragma once


/*
    *    util/bot/includes/detection/debug.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


bool debug_detection(void);