#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#pragma once


/*
    *    util/loader/includes/io/handler.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void handler(int argc, char **argv);
bool check_args(int argc, char **argv);