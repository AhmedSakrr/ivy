package commands

import (
	"os"
)


/*
    *    util/commands/exit.go
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


func ExitCommands() {
	os.Exit(1)
}