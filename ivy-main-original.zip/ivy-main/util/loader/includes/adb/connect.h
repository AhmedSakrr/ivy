#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#pragma once


/*
    *    util/loader/includes/adb/connect.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void adb_connect_load(char *ipaddr, char *payload);