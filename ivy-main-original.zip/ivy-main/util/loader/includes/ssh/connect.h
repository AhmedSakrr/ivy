#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libssh/libssh.h>
#pragma once


/*
    *    util/loader/includes/ssh/connect.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


void ssh_load(char *ipaddr, char *password, char *payload);