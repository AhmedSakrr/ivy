#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/sysinfo.h>
#pragma once


/*
    *    util/bot/includes/detection/debug.h
    *    Date: 12/11/21
    *    Author: 0x80000000
*/


bool d_uptime(void);